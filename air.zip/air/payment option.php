<html>
    <head>
        <title>
            payment option
        </title>
        <link rel="stylesheet" type="text/css" href="bootstrap.css">
        <script  src="bootstrap.min.js"></script>
         <script src="jquery.min.js"></script>
  <script src="bootstrap.min.js"></script>
      <link rel="stylesheet" type="text/css" href="pay.css">
    </head>
    <body>
      
    <h1 style="color: whitesmoke;">Payment Options</h1>
        <div class="container">
    <div class="row">
  <div class="col">
 <div class="card " style="width: 15rem;">

  <img src="1c.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Commercial Bank of Ethiopia</h5>
    <p class="card-text"></p>
    <button data-target="#btn1" data-toggle="modal" class="btn btn-success">Pay By CBE</button>
  </div>
</div></div>

<div class="col">
<div class="card" style="width: 15rem;">
  <img src="dashin1.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Dashin Bank</h5>
    <p class="card-text"></p>
    <button data-target="#btn1" data-toggle="modal" class="btn btn-warning">Pay By Dashin</button>
  </div>
</div>
</div>


<div class="col">
<div class="card" style="width: 15rem;">
  <img src="a1.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Awash Bank</h5>
    <p class="card-text"></p>
    <button data-target="#btn1" data-toggle="modal" class="btn btn-danger">Pay By Awash</button>
  </div>
</div>
</div>
</div>
        <div class="modal fade" id="btn1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" >
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Payment Form</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body d-flex justify-content-start" >
        
          <table class="d-flex justify-content-start" border="0" cellpadding="5" cellspacing="0" align="top" >
            <form>
            <tr>
        <td>Mobile Banking Password:</td><td> <input type="password" name=""></td> <br> <br> 
      </tr>
      <tr>
     <td> Passport ID: </td><td><input type="text" name=""></td><br><br>
   </tr>
   <tr>
      <td>Account Number:</td><td> <input type="text" name=""></td></tr></table>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Confirm</button>
      </div>
    </div>
  </div>
</div>
       
        
    </body>
    
</html>