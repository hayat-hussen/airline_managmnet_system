<?php

$pdo= new PDO('mysql:host=localhost;port=3306;dbname=airline','root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$fname = $lname = $phone =$email =$date = $sex="";

if($_SERVER['REQUEST_METHOD'] =='POST'){



$fname = $_POST['fname'];
$lname=$_POST['lname'];
$phone = $_POST['phone'];
$email = $_POST["email"];
$nation= $_POST["nation"];
$sex = $_POST["sex"];

  $query=("INSERT INTO usertable(firstname, lastname, phonenumber,email, nation,  gender) VALUES(:firstname, :lastname, :phonenumber,:email, :nation, :gender)");

$pdo_run= $pdo->prepare($query);
$pdo_execute= $pdo_run->execute(array(":firstname" => $fname, ":lastname"=> $lname, ":phonenumber"=>$phone,":email"=>$email, ":nation"=>$nation, ":gender"=>$sex));
 
header("Location: GetTciket.php");
}


  
  


// $statement=$pdo->prepare("INSERT INTO products (title, description, image , price, create_date )
//           VALUES(:title , :description, '', :price , :date)");
// $statement=$pdo->prepare("INSERT INTO products (title, description, image , price, create_date )
// VALUES($title , $description, '', $price , $date)");



// // $statement->bindValue(':title' ,$title);
// // $statement->bindValue(':image' , '');
// // $statement->bindValue(':description' ,$description);
// // $statement->bindValue(':price', $price);
// // $statement->bindValue(':date' ,$date);
//   $statement->execute();
//array(":title" => $title, ":image"=> "", ":description"=>$description, ":price"=>$price, ":date"=>$date)



// if ($pdo_execute){
//      echo "<script> alert('the data is inserted')</script>";
// }else{
//   echo "<script> alert('the data is not inserted')</script>";
// }





?>




<!DOCTYPE HTML>
<html>
<head>
<title>fill_tarveler_detail</title>


<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<!-- Stylesheet -->
<link href="form.css" rel='stylesheet' type='text/css' /> 
<!-- //Stylesheet -->
<!-- fonts --> 
<link href="https://fonts.googleapis.com/css?family=Flamenco" rel="stylesheet">  
<link rel="stylesheet" type="text/css" href="cs.css">
<link rel="stylesheet" type="text/css" href="bootstrap.css">

<!-- // fonts-->
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand fa-home" href="index.php">Home</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
      
          <ul class="navbar-nav mr-auto fixed">
            <li class="nav-item active">
            <a class="nav-link" href="flight status.php">Avaliable Flights </a>
            </li>
           
          
           
            <li class="nav-item">
              <a class="nav-link" href="log.php" tabindex="-1" aria-disabled="true">System User</a>
            </li>
          </ul>
         
      
        </div>
      </nav><br>
<!--background-->
<h2 style="text-align: center;">please Fill out the form</h2>

    <div class="bg-agile">
	<div class="book-appointment">
						<div class="book-form agileits-login">
							<form action="GetTciket.php" method="post">
								<div class="agileits_reservation_grid">
								<div class="phone_email">
									<div class="form-text">
										<i class="fa fa-user" aria-hidden="true"></i>
										<input type="text" name="fname" placeholder="First name" required="" autocomplete="off">
									</div> 
								</div>
								<div class="phone_email phone_email1">
									<div class="form-text">
										<i class="fa fa-user" aria-hidden="true"></i>
										<input type="text" name="lname" placeholder="Last name" required="" autocomplete="off">
									</div>
								</div>
								
								<div class="phone_email">
									<div class="form-text">
										<i class="fa fa-phone" aria-hidden="true"></i>
										<input type="text" name="phone" placeholder="Phone number" required="" autocomplete="off">
									</div> 
								</div> 
								<div class="phone_email phone_email1">
									<div class="form-text">
										<i class="fa fa-envelope-o" aria-hidden="true"></i>
										<input type="email" name="email" placeholder="Email" required="" autocomplete="off">
									</div>
								</div>
									
								
								
								<div class="span1_of_1 phone_email">
										<div class="book_date"> 
											<i aria-hidden="true"></i>
												<input id="datepicker1" name="nation" type="text" value="" placeholder="Nationality"  onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'mm/dd/yyyy';}" required="">

										</div>					
									</div>
								  	
								  

									<div class="span1_of_1 phone_email1">
										<!-- start_section_room -->
										<div class="section_room">
											<i class="fa fa-h-square" aria-hidden="true"></i>
                                           
                                            <select name="sex" id="country1" onchange="change_country(this.value)" class="frm-field required">
                                                <option>Male</option>
												<option>Female</option>
												

											</select>
										</div>	
									</div>
									
									<div class="clear"></div>
								</div> 
                                <input class="btn btn-success" type="submit">
								
								<div class="clear"></div>
							</form>
						</div>

		</div>
   </div>
   		
	



</body>
</html>