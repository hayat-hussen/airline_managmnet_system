
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Transparent Login Form HTML CSS</title>
  <link rel="stylesheet" type="text/css" href="bootstrap.css">
        <script  src="bootstrap.min.js"></script>
         <script src="jquery.min.js"></script>
  <script src="bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand fa-home" href="index.php">Home</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
    
        <ul class="navbar-nav mr-auto fixed">
          <li class="nav-item active">
            <a class="nav-link" href="flight status.php">Avaliable Flights </a>
          
        
         
          <li class="nav-item">
            <a class="nav-link" href="hotel.html" tabindex="-1" aria-disabled="true">Hotel</a>
          </li>
        </ul>
       
    
      </div>
    </nav> 


<form action="" method="post">

<br><br><br><br><br>
<div style="width: 50%; background-color: white; border-radius: 0.3rem; box-shadow: 0 0.2rem rgba(0, 0, 0, .19);" class="widget_tab_wrapper widget--items4 border border-info container">
   <ul class="nav nav-tabs">
   <li class="nav-item text-center show nav-link active h3" style="color:black;">   Admin page</li> </ul>
   
 <br><br>
     <div class="field js-fields field--focus active text-justify">
      <p><label class="field__text" tabindex="-1">Email Address:</label>  
     <input class="js-field-input field__input js-dropdown-open field__input--active" placeholder="Your Email Address" name="email" type="text">  </p>
     <p>
    <label class="field__text" tabindex="-1">Password:</label> 
    <input  class="js-field-input field__input js-dropdown-open field__input--active" placeholder="Your Password" type="password" name="password"> </p> 

    <p style="text-align: center;">
    <input class="js-field-input field__input js-dropdown-open field__input--active" type="submit" value="log in" name='submit'></p>

   

   </p>
  </div>
  
</div>
</form>
<?php
    if(isset($_POST["submit"])){  
  
  if(!empty($_POST['email']) && !empty($_POST['password'])) {  
      $user=$_POST['email'];  
      $pass=$_POST['password'];  
    
      $con=mysqli_connect('localhost','root','') or die(mysqli_error($con));  
      mysqli_select_db($con, 'airline') or die("cannot select DB");  
    
      $query=mysqli_query($con, "SELECT * FROM admindb WHERE email='".$user."' AND password='".$pass."'");  
      $numrows=mysqli_num_rows($query);  
      if($numrows!=0)  
      {  
      while($row=mysqli_fetch_assoc($query))  
      {  
      $dbusername=$row['email'];  
      $dbpassword=$row['Password'];  
      }  
    
      if($user == $dbusername && $pass == $dbpassword)  
      {  
      session_start();  
      $_SESSION['sess_user']=$user;  
    
      /* Redirect browser */  
      header("Location:login part1.php");  
      }  
      } else {  
      echo "Invalid email or password!";  
      }  
    
  } else {  
      echo "All fields are required!";  
  }  
  }  
  ?>  
  
</body>
</html>