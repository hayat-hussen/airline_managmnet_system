<!DOCTYPE html>
<html>
<head>
	<title>Ethiopian AirLine</title>
		<link rel="stylesheet" type="text/css" href="bootstrap.css">
	<link rel="stylesheet" type="text/css" href="fontawesome.css">
   <script src="modal.js"></script>
       <script src="bootstrap.bundle.min.js"></script>
  <script src="bootstrap.min.js"></script>
    <script src="jquery.min.js"></script>
</head>

<body class="">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand fa-home" href="#">Home</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">

    <ul class="navbar-nav mr-auto fixed">
      <li class="nav-item active">
        <a class="nav-link" href="flight status.php">Avaliable Flight <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="hotel.html">Hotel</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="log.php">System User</a>
      </li>
     
    </ul>

  </div>
</nav>

<br>
            <div class="hero-block hero-v8 bg-img-hero-bottom text-center gradient-overlay-half-bg-violet-light z-index-2" >
                <div class="container space-2 space-top-lg-3 space-top-xl-6">
                    <div class="row justify-content-md-center pb-4">
                <img src="icon.png">        <div class="pb-lg-8 pb-xl-11 pb-3">
                           <br><br><br> <h1 style="color:black" class="font-size-60 font-size-xs-30 "><h1> New Sprit Of Africa</h1>
                        </div>
                    </div></div>
                  

  <div class="media">
  <div class="media-body">
  <div class="spinner-grow text-success" role="status">
  <span class="sr-only">Loading...</span>
</div>
<div class="spinner-grow text-warning" role="status">
  <span class="sr-only">Loading...</span>
</div>
<div class="spinner-grow text-danger" role="status">
  <span class="sr-only">Loading...</span>
</div>
    <h1 class="mt-0" style="color:green;">Ethiopian Airlines</h1>
   <h1 style="color:yellow;">With Us Everyone Can Fly</h1>
   <h1 style="color:red;">Lets Fly Into Tomorrow </h1>
  </div>
</div><br><br>

 
<div style="width: 40%; background-color: white; border-radius: 0.3rem; box-shadow: 0 0.2rem rgba(0, 0, 0, .19);" class="widget_tab_wrapper widget--items4 border border-info container">
 <h4>Click On The Button To Check Flights </h4>
 
     <div class="field js-fields field--focus active text-justify"><label class="field__text" tabindex="-1"></label>   
   
    <p style="text-align: center;"> <a class="btn btn-success" href="flight status.php" role="button">Check Flights</a></p>
  </div>
  
</div>


<br>

	<h1 style="color: black;text-align: center;" >Travel Safely With Us</h1><br>
  <div style="width: 100%; background-color:whitesmoke ; border-radius: 0.3rem; box-shadow: 0 0.2rem rgba(0, 0, 0, .19);" class="widget_tab_wrapper widget--items4">
    <nav aria-label="Page navigation example">
  <ul class="pagination justify-content-center">
  <div class="container">
    <div class="row">
	<div class="col">
 <div class="card " style="width: 15rem;">

  <img src="mekele.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Mekele City</h5>
    <a href="flight status.php" class="btn btn-warning">Book now</a>
    
  </div>
</div></div>

<div class="col">
<div class="card" style="width: 15rem;">
  <img src="dubai.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Dubai</h5>
    <a href="flight status.php" class="btn btn-warning">Book now</a>
  </div>
</div>
</div>


<div class="col">
<div class="card" style="width: 15rem;">
  <img src="lalibela1.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Lalibela</h5>
    <a href="flight status.php" class="btn btn-warning">Book now</a>
  </div>
</div>
</div>
</div>
<div class="row">
	<div class="col">
 <div class="card " style="width: 15rem;">

  <img src="turkey.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Turkey</h5>
    <a href="flight status.php" class="btn btn-warning">Book now</a>
  </div>
</div></div>

<div class="col">
<div class="card" style="width: 15rem;">
  <img src="axum1.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Axum city</h5>
    <a href="flight status.php" class="btn btn-warning">Book now</a>
  </div>
</div>
</div>


<div class="col">
<div class="card" style="width: 15rem;">
  <img src="spain.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Spain</h5>
    <a href="flight status.php" class="btn btn-warning">Book now</a>
  </div>
</div>
</div>
</div>
<div class="row">
<div class="col">
<div class="card" style="width: 15rem;">
  <img src="usa.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">USA</h5>
    <a href="flight status.php" class="btn btn-warning">Book now</a>
  </div>
</div>
</div>

<div class="col">
<div class="card" style="width: 15rem;">
  <img src="Bahirdar.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Bahirdar city</h5>
    <a href="flight status.php" class="btn btn-warning">Book now</a>
  </div>
</div>
</div>

<div class="col">
<div class="card" style="width: 15rem;">
  <img src="china.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">China</h5>
    <a href="flight status.php" class="btn btn-warning">Book now</a>
  </div>
</div>
</div>
</div>
</div>
</div>
<h1 style="color: black; text-align: center;" a>Travel With Confident</h1><br>



  <div style="width: 100%; background-color:whitesmoke ; border-radius: 0.3rem; box-shadow: 0 0.2rem rgba(0, 0, 0, .19);" class="widget_tab_wrapper widget--items4">
    <nav aria-label="Page navigation example">
  <ul class="pagination justify-content-center">
  <div class="container">
    <div class="row">
	<div class="col">
 <div class="card " style="width: 15rem;">

  <img src="ap1.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Travel Requirement</h5>
    <p>Find the latest travel requirement by country,option for your booking,important health and safty measurement and more </p>
    <a href="travel requirement.html" class="btn btn-warning">Read more</a>
  </div>
</div></div>

<div class="col">
<div class="card" style="width: 15rem;">
  <img src="safty.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Safty Measurement</h5>
    <p>We have launched a new built airport  with bio safty and bio security in mind, as we always do,putting the safty and awerness of our passenger and worker</p>
    <a href="safty.html" class="btn btn-warning">Read More</a>
  </div>
</div>
</div>


<div class="col">
<div class="card" style="width: 15rem;">
  <img src="flex.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Flexable Travel</h5>
    <p>Booking terms are now flexible than ever in Ethiopian airline</p>
    <a href="Flexable Travel.html" class="btn btn-warning">Read More</a>
  </div>
</div>
</div>
</div>
<div class="row">
	<div class="col">
 <div class="card " style="width: 15rem;">

  <img src="sheba.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">sheba Comfort</h5>
    <p>Sheba Comfort is one of the extra security measures we have implemented to keep your health as our frist priority</p>
    <a href="sheba.html" class="btn btn-warning">Read More</a>
  </div>
</div></div>
</div>
</div>
</div>
<div class="product-card-block product-card-v7 border-bottom border-color-8">
                
            <!-- End Product Cards Carousel with Brands -->

          

            <div class="space-1">
                <div class="container">
                    <div class="d-lg-flex d-md-block justify-content-between align-items-center">
                       
                      </div></div></div>
                      <p class="mb-3 mb-lg-0 text-gray-1;" style="text-align: center;">© 2022 MyTravel. All rights reserved</p>
                      <p style="text-align: center;">
                      <img src="icon.png" height="10%" width="10%" >
                      <img src="satrallince.png"height="10%" width="10%"  ></p>



</body>
</html>