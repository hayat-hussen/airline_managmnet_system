<?php
function randomString($n){
  $characters = '0123456789abcdefghijklmnopqrstuvwxyzQWERTYUIOPASDFGHJKLZXCVBNM';
  $str = '';
  for($i=0; $i<$n; $i++){
    $index = rand(0, strlen($characters)-1);
    $str.=$characters[$index];
  }
  return $str;
}

$ticketnumber = randomString(10);

 $fname=$_POST['fname'];
 $lname=$_POST['lname'];
 $phone=$_POST['phone'];
 $nationality=$_POST['nation'];
 $email=$_POST['email'];
 $sex=$_POST['sex'];

 



?>
<!DOCTYPE html>
<html>
    <head>
        <title>GetTIcket</title>
        </title>
        <link rel="stylesheet" type="text/css" href="bootstrap.css">
        <link rel="stylesheet" type="text/css" href="get.css">
      
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
     
        </head>
        <body>
          
            <div class="booking-form-box" style="max-width: 600px;">
                <div class="booking-form">
                    <h1>Ticket</h1>
                    <div >
                        <label><b>Title</b></label>
                      
                      </div>
                      </div>
                      <form method="post" name="MyForm" onsubmit="validate();vaE();">
                        <div >
                          <label><b>Ticket number: </b> <?php echo $ticketnumber ?></label>
                        </div>
                      <div >
                        
                        <i class="fa fa-user"></i>
                        <label><b>First name: </b>  <?php echo $fname ?></label><br>
                      </div>
                      <div >
                        <i class="fa fa-user"></i>
                        <label><b>Last name: </b>  <?php echo $lname ?></label><br>
                      </div>
                      
                      <div >
                        <i class="fa fa-user"></i>
                        <label><b>Nationality: </b>  <?php echo $nationality ?></label><br>
                      </div>
                       
                      <div >
                        <i class="fa fa-phone"></i>
                        <label><b>phone number: </b>  <?php echo $phone ?></label><br>
                      </div>
                      <div >
                        <i class="fa fa-envelope"></i>
                        <label><b>E-mail: </b>  <?php echo $email ?></label>  <br>
                      </div>
                      
                        <div >
                        <label><b>Sex</b> <?php echo $sex ?></label></div>
                        
                        </label>
                    
                    
                     
                   
                      <div>
                        <a href="index.php"><button type="button" class="btn btn-info">Print</button></a>
    
           
              </div>
            </form>
                </div>
             
        </body>
    
</html>