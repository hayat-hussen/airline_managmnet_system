<?php
$id = $_GET['id'] ?? null;

if (!$id) {
    header('Location: admin.php');
    exit;
}

$pdo = new PDO('mysql:host=localhost;port=3306;dbname=airline', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$statement = $pdo->prepare('SELECT * FROM flightinfo WHERE id = :id');
$statement->bindValue(':id', $id);
$statement->execute();
$informations = $statement->fetch(PDO::FETCH_ASSOC);

$flightid= $informations['flightId'];
$Arrivaltime = $informations['ArrivalTime'];
$DepartureTime = $informations['DepartureTime'];

$arrivalPoint = $informations['arrivalpoint'];
$departurePoint = $informations['departurepoint'];
$reservedSeat = $informations['reservedseat'];
$unreservedSeat =$informations['UnreservedSeat'];
$price = $informations['price'];

$flightider = $arrivaltimeer = $departuretimeer =$reservedSeater= $unreservedSeater =$priceer=$fromer=$toer = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

if (empty($_POST["flightId"])&&empty($_POST["arrivaltime"])&&empty($_POST["departureTime"])&&empty($_POST["reservedSeat"])&&empty($_POST["unreservedSeat"])&&empty($_POST["price"])){
  $arrivaltimeer= "*Arrival time is required!";
  $flightider = "*flight number is required!";
  $departuretimeer = "*departure time is required!";
  $reservedSeater = "*reserved Seat is required!";
  $unreservedSeater = "*unreserved Seat is required!";
  $priceer = "*price is required!";
  $fromer = "*from is required!";
  $toer = "*to is required!";


}else{

  $flightid = $_POST['flightno'];
  $arrivaltime=$_POST['arrivaltime'];
  $departuretime = $_POST['departureTime'];
  $reservedSeat = $_POST["reservedSeat"];
  $unreservedSeat = $_POST["unreservedSeat"];
  $price = $_POST["price"];
  $from= $_POST["from"];
  $to = $_POST["to"];

      $statement =$pdo->prepare("UPDATE flightinfo SET flightId = :flightid, ArrivalTime = :arrivaltime, DepartureTime = :departuretime, arrivalpoint = :arrivalpoint, departurepoint = :departurepoint,  reservedseat = :reservedseat, UnreservedSeat = :unreservedseat, price = :price WHERE id = :id");
      $statement->bindValue(':flightid',$flightid );
      $statement->bindValue(':arrivaltime',$arrivaltime);
      $statement->bindValue(':departuretime',$departuretime);
      $statement->bindValue(':arrivalpoint',$arrivalPoint );
      $statement->bindValue(':departurepoint',$departurePoint);
      $statement->bindValue(':reservedseat',$reservedSeat);
      $statement->bindValue(':unreservedseat',$unreservedSeat);
      $statement->bindValue(':price',$price);
      $statement->bindValue(':id',$id);
      $statement->execute();
      //$pdo_execute= $pdo_run->execute(array(":flightid" => $flightid, ":arrivaltime" => $arrivaltime, ":departuretime "=> $departuretime,":arrivalpoint" => $from, ":departurepoint"=>$to,  ":reservedseat"=>$reservedSeat,  ":unreservedseat"=>$unreservedSeat,  ":price" =>$price, ":id" =>$id));
     
      
        header('Location: admin.php');
}

}
?>
<!DOCTYPE html>
<html>
    <head>
      
        <title>login part1</title>
        <link rel="stylesheet" type="text/css" href="sc.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="bootstrap.css">
      
    </head>
    <body >
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand fa-home" href="index.php">Home</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
    
        <ul class="navbar-nav mr-auto fixed">
          <li class="nav-item active">
          <a class="nav-link" href="flight status.php">Avaliable Flights </a>
         
        
         
          <li class="nav-item">
            <a class="nav-link" href="log.php" tabindex="-1" aria-disabled="true">System User</a>
          </li>
        </ul>
       
    
      </div>
    </nav>
      <div class="container">
      <nav class="navbar navbar-expand-lg navbar-light  bg-light ">
        <a class="navbar-brand" href="login part1.html">Home</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-item nav-link" href="login part3.html">Available flights</a>
            <a  class="nav-item nav-link" href="log.html">logout</a>
          </div>
        </div>
      </nav>
 <form action="" method="post">
    <div class="form-control">
      <div class="booking-form">
      
      <div class="input-grp">
      
      <label for="flight number">Flight Number:</label>
      <input type="text" id="reserved seat" value=<?php echo  $flightid ?> name="flightno" class="form-control"><span> <?php echo  $flightider;?> </span>
      </div>
      <br>
    <div class="input-grp">
    
        <label for="arrival time"><b>arrival time:</b></label>
        <input type="datetime-local" id="arrival time"value=<?php echo  $Arrivaltime ?> name="arrivaltime" class="form-control select-date">   <span> <?php echo  $arrivaltimeer;?> </span>
        </div><br>
        <div class="input-grp">
        <label for="departure time">departure time:</label>
        <input type="datetime-local" id="departure time" value=<?php echo  $DepartureTime ?> name="departureTime"class="form-control select-date" ><span> <?php echo  $departuretimeer;?> </span>
    </div><br>
    <div class="input-grp>">
        <label for="select flight">From:</label>
        <select class="form-control" value=<?php echo  $arrivalPoint ?> name="from" id="select flight"><span> 
          <option>Addis Ababa</option>
          <option>Dire Dawa</option>
          <option>Gonder</option>
          <option>Bahir Dar</option>
          <option>Hawassa</option>
          <option>Assosa</option>
          <option>Jimma</option>
          <option>Dubai</option>
          <option>Saudi Arabia</option>
          <option>USA</option>
          <option>Germany</option>
          <option>Spain</option>
          <option>Italy</option>
          <option>Congo</option>
        </select>
    </div>
    <div class="input-grp>">
        <label for="select flight">To:</label>
        <select style="color: black;" value=<?php echo  $departurePoint ?> class="form-control" name="to" id="select flight">
          <option>Addis Ababa</option>
          <option>Dire Dawa</option>
          <option>Gonder</option>
          <option>Bahir Dar</option>
          <option>Hawassa</option>
          <option>Assosa</option>
          <option>Jimma</option>
          <option>Dubai</option>
          <option>Saudi Arabia</option>
          <option>USA</option>
          <option>Germany</option>
          <option>Spain</option>
          <option>Italy</option>
          <option>Congo</option>
        </select>
    </div>
    <br>
    <div class="input-grp">
      
      <label for="reserved seat">Reserved seat:</label>
      <input type="text" id="reserved seat" value=<?php echo  $reservedSeat ?> name="reservedSeat"class="form-control"><span> <?php echo  $reservedSeater;?> </span>
      </div>
      
    <div class="input-grp">
      <label for="unreserved seat">unreserved seat:</label>
      <input type="number" id="unreserved seat" value=<?php echo  $unreservedSeat ?> name="unreservedSeat"class="form-control"><span> <?php echo  $unreservedSeater;?> </span>
  </div>
  <br>
  <div class="input-grp">
      <label for="price">price:</label>
      <input type="number" id="unreserved seat" value=<?php echo  $price ?> name="price"class="form-control"><span> <?php echo  $priceer;?> </span>
  </div>
  <div>
    <br>
    <button type="submit" class="btn btn-success">Set Flight</button>
    <a href="admin.php"><button type="submit" class="btn btn-success">Back</button></a>

  </div>
 
 
</div>
             
  
 
    </body>
</html>