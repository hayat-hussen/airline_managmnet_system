<?php

$pdo= new PDO('mysql:host=localhost;port=3306;dbname=airline','root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$statement = $pdo->prepare('SELECT * FROM flightinfo');
$statement->execute();
$infos=$statement->fetchAll(PDO::FETCH_ASSOC);

?>



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="app.css" >
    <title>Available Flights</title>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand fa-home" href="index.php">Home</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
    
        <ul class="navbar-nav mr-auto fixed">
          <li class="nav-item active">
          <a class="nav-link" href="flight status.php">Avaliable Flights </a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="check in.html">Check In</a>
          </li>
        
         
          <li class="nav-item">
            <a class="nav-link" href="log.php" tabindex="-1" aria-disabled="true">System User</a>
          </li>
        </ul>
       
    
      </div>
    </nav>
    <h1>Available flights</h1>
    
    <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">flight Number</th>
      <th scope="col">Arrival Time</th>
      <th scope="col">Departure Time</th>
      <th scope="col">From</th>
      <th scope="col">To</th>
      <th scope="col">Reserved Seat</th>
      <th scope="col">Unreserved Seat</th>
      <th scope="col">price</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
   <?php
   foreach($infos as $i => $info):?>
   <tr>
       <th scope="row"><?php echo $i+1 ?></th>
       <td>
          <?php echo $info['flightId']?>
       </td>
       <td><?php echo $info['ArrivalTime'] ?></td>
      
       
       <td><?php echo $info['DepartureTime']?></td>
       <td><?php echo $info['arrivalpoint']?></td>
       <td><?php echo $info['departurepoint']?></td>
       <td><?php echo $info['reservedseat']?></td>
       <td><?php echo $info['UnreservedSeat']?></td>
       <td><?php echo $info['price']?></td>

       <td>
       <a href="update.php?id=<?php echo $info['id'] ?>" class="btn btn-success">Edit</a>
       <form style= "display: inline-block" action = "delete.php" method="post">
       <input type="hidden" name="id" value="<?php echo $info['id'] ?>">
       <button type="submit" class="btn btn-danger">delete</button>
        </form>
   </td>
   </tr>

  <?php endforeach; ?>
  </tbody>
</table>

<p style="text-align: center;">
    <a href= "login part1.php" class="btn btn-success">create New Flight</a>
    </p> 
  </body>
</html>