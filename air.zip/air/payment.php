 <?php

$error= "";

$pdo = new PDO('mysql:host=localhost;port=3306;dbname=airline', 'root', '');
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
if(isset($_POST["submit"])){  

 // $id = $_POST['id'] ?? null;
 $id=$_GET['id'];  
 

  if(!empty($_POST['accnum']) && !empty($_POST['password'])) {  
      $accnum=$_POST['accnum'];  
      $pass=$_POST['password'];  
      $user = $_POST["username"];

    
      $con=mysqli_connect('localhost','root','') or die(mysqli_error($con));  
      mysqli_select_db($con, 'bankdb') or die("cannot select DB"); 
    
      $query=mysqli_query($con, "SELECT * FROM banktable WHERE accounnum='".$accnum."' AND password='".$pass."'");  
      $numrows=mysqli_num_rows($query);  
      if($numrows!=0)  
      {  
      while($row=mysqli_fetch_assoc($query))  
      {  
      $dbacc=$row['accounnum'];  
      $dbpassword=$row['password'];  
      }  
    
      if($accnum == $dbacc && $pass == $dbpassword)  
      {  
      session_start();  
      $_SESSION['sess_user']=$accnum;  
    
      // if(!$id){
        //header('Location:fill_tarveler_detail.php');
        //exit;
        
        $statement = $pdo->prepare('SELECT * FROM flightinfo WHERE id = :id');
        $statement->bindValue(':id', $id);
        $statement->execute();
        $informations = $statement->fetch(PDO::FETCH_ASSOC);

        $price = $informations['price'];
        $que=mysqli_query($con, "SELECT *  FROM banktable WHERE accounnum='".$accnum."' AND password='".$pass."'");
        $row=mysqli_fetch_assoc($que);
        $balance=$row['balance'];

        $newbalance =(int)$balance - (int)$price;
        $que=mysqli_query($con, "UPDATE banktable SET balance= $newbalance  WHERE accounnum='".$accnum."' AND password='".$pass."'");

        
        echo "<script>alert('payement done successfully Please fill the form')</script>" ;
        header("location:fill_tarveler_detail.php");

      }
      }
      else{
       
        echo "<p style =color:red; >*invalid username or password<p>";
      }
    }else {  
  
      $error = "*field  required!"; 
      }  
    
  } 


?>



<!DOCTYPE html>
<html>
    <head>
        <title>
            payment option
        </title>
        <link rel="stylesheet" type="text/css" href="bootstrap.css">
        <script  src="bootstrap.min.js"></script>
         <script src="jquery.min.js"></script>
  <script src="bootstrap.min.js"></script>
    </head>
    <body>
          <form action="" method="post">

         <br><br><br><br><br>
        <div style="width: 50%; background-color: white; border-radius: 0.3rem; box-shadow: 0 0.2rem rgba(0, 0, 0, .19);" class="widget_tab_wrapper widget--items4 border border-info container">
            <ul class="nav nav-tabs">
            <li class="nav-item text-center show nav-link active h3" style="color:black;">please fill the form to pay</li> </ul>
            
          <br><br>
              <div class="field js-fields field--focus active text-justify"><label class="field__text" tabindex="-1">Account Number:</label>   
            <input class="js-field-input field__input js-dropdown-open field__input--active" type="text" name="accnum">  <span><?php echo $error  ?></span>
              <br> <br>
             <label class="field__text" tabindex="-1">username:</label> <input class="js-field-input field__input js-dropdown-open field__input--active" type="text" name="username"> <span><?php  echo $error  ?></span>

             <br> <br>
             <label class="field__text" tabindex="-1">password:</label> <input class="js-field-input field__input js-dropdown-open field__input--active" type="text" name="password"> <span><?php echo $error  ?></span>
             <br><br>
              

             <p> <input type="submit" name="submit" value="pay" class="btn btn-success"> 
                
                <input type="button" value="Go back" class="btn btn-primary"> 

            </p>
           </div>
           
         </div>
         </form>
        
    </body>
    
</html>