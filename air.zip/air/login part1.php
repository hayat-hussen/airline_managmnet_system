<?php

$pdo= new PDO('mysql:host=localhost;port=3306;dbname=airline','root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$flightid = $arrivaltime = $departuretime =$reservedSeat =$unreservedSeat = $price=$from=$to ="";
$flightider = $arrivaltimeer = $departuretimeer =$reservedSeater= $unreservedSeater =$priceer=$fromer=$toer = "";
$errors = [];
if($_SERVER['REQUEST_METHOD'] =='POST'){

 

if (empty($_POST["flightId"])&&empty($_POST["arrivaltime"])&&empty($_POST["departureTime"])&&empty($_POST["reservedSeat"])&&empty($_POST["unreservedSeat"])&&empty($_POST["price"])){
  $arrivaltimeer= "*Arrival time is required!";
  $flightider = "*flight number is required!";
  $departuretimeer = "*departure time is required!";
  $reservedSeater = "*reserved Seat is required!";
  $unreservedSeater = "*unreserved Seat is required!";
  $priceer = "*price is required!";
  $fromer = "*from is required!";
  $toer = "*to is required!";


}else{
$flightid = $_POST['flightId'];
$arrivaltime=$_POST['arrivaltime'];
$departuretime = $_POST['departureTime'];
$reservedSeat = $_POST["reservedSeat"];
$unreservedSeat = $_POST["unreservedSeat"];
$price = $_POST["price"];
$from= $_POST["from"];
$to = $_POST["to"];
  $query=("INSERT INTO flightinfo(flightId, ArrivalTime, DepartureTime,arrivalpoint,departurepoint,  reservedseat, UnreservedSeat, price) VALUES(:flightid, :arrivaltime, :departuretime,:arrivalpoint, :departurepoint, :reservedseat ,:unreservedseat, :price)");

$pdo_run= $pdo->prepare($query);
$pdo_execute= $pdo_run->execute(array(":flightid" => $flightid, ":arrivaltime"=> $arrivaltime, ":departuretime"=>$departuretime,":arrivalpoint"=>$from, ":departurepoint"=>$to, ":unreservedseat"=>$unreservedSeat,  ":reservedseat"=>$reservedSeat, ":price"=>$price));

}


  
  


// $statement=$pdo->prepare("INSERT INTO products (title, description, image , price, create_date )
//           VALUES(:title , :description, '', :price , :date)");
// $statement=$pdo->prepare("INSERT INTO products (title, description, image , price, create_date )
// VALUES($title , $description, '', $price , $date)");



// // $statement->bindValue(':title' ,$title);
// // $statement->bindValue(':image' , '');
// // $statement->bindValue(':description' ,$description);
// // $statement->bindValue(':price', $price);
// // $statement->bindValue(':date' ,$date);
//   $statement->execute();
//array(":title" => $title, ":image"=> "", ":description"=>$description, ":price"=>$price, ":date"=>$date)



// if ($pdo_execute){
//      echo "<script> alert('the data is inserted')</script>";
// }else{
//   echo "<script> alert('the data is not inserted')</script>";
// }



}

?>




<!DOCTYPE html>
<html>
    <head>
      
        <title>login part1</title>
        <link rel="stylesheet" type="text/css" href="sc.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="bootstrap.css">
      
    </head>
    <body >
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand fa-home" href="index.php">Home</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
    
        <ul class="navbar-nav mr-auto fixed">
          <li class="nav-item active">
          <a class="nav-link" href="flight status.php">Avaliable Flights </a>
          </li>
        
         
          <li class="nav-item">
            <a class="nav-link" href="log.php" tabindex="-1" aria-disabled="true">System User</a>
          </li>
        </ul>
       
    
      </div>
    </nav>
      <div class="container">
      <nav class="navbar navbar-expand-lg navbar-light  bg-light ">
        <a class="navbar-brand" href="login part1.html">Home</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav">
            <a class="nav-item nav-link" href="admin.php">Available flights</a>
            <a  class="nav-item nav-link" href="log.php">logout</a>
          </div>
        </div>
      </nav>
 <form action="" method="post">
    <div class="form-control">
      <div class="booking-form">
      
      <div class="input-grp">
      
      <label for="reserved seat">Flight Number:</label>
      <input type="text" id="reserved seat" name="flightId"class="form-control"><span> <?php echo  $flightider;?> </span>
      </div>
      <br>
    <div class="input-grp">
    
        <label for="arrival time"><b>arrival time:</b></label>
        <input type="datetime-local" id="arrival time" name="arrivaltime" class="form-control select-date">   <span> <?php echo  $arrivaltimeer;?> </span>
        </div><br>
        <div class="input-grp">
        <label for="departure time">departure time:</label>
        <input type="datetime-local" id="departure time" name="departureTime"class="form-control select-date" ><span> <?php echo  $departuretimeer;?> </span>
    </div><br>
    <div class="input-grp>">
        <label for="select flight">From:</label>
        <select class="form-control" name="from" id="select flight"><span> 
          <option>Addis Ababa</option>
          <option>Dire Dawa</option>
          <option>Gonder</option>
          <option>Bahir Dar</option>
          <option>Hawassa</option>
          <option>Assosa</option>
          <option>Jimma</option>
          <option>Dubai</option>
          <option>Saudi Arabia</option>
          <option>USA</option>
          <option>Germany</option>
          <option>Spain</option>
          <option>Italy</option>
          <option>Congo</option>
        </select>
    </div>
    <div class="input-grp>">
        <label for="select flight">To:</label>
        <select style="color: black;" class="form-control" name="to" id="select flight">
          <option>Addis Ababa</option>
          <option>Dire Dawa</option>
          <option>Gonder</option>
          <option>Bahir Dar</option>
          <option>Hawassa</option>
          <option>Assosa</option>
          <option>Jimma</option>
          <option>Dubai</option>
          <option>Saudi Arabia</option>
          <option>USA</option>
          <option>Germany</option>
          <option>Spain</option>
          <option>Italy</option>
          <option>Congo</option>
        </select>
    </div>
    <br>
    <div class="input-grp">
      
      <label for="reserved seat">Reserved seat:</label>
      <input type="text" id="reserved seat" name="reservedSeat"class="form-control"><span> <?php echo  $reservedSeater;?> </span>
      </div>
      
    <div class="input-grp">
      <label for="unreserved seat">unreserved seat:</label>
      <input type="number" id="unreserved seat" name="unreservedSeat"class="form-control"><span> <?php echo  $unreservedSeater;?> </span>
  </div>
  <br>
  <div class="input-grp">
      <label for="price">price:</label>
      <input type="number" id="unreserved seat" name="price"class="form-control"><span> <?php echo  $priceer;?> </span>
  </div>
  <div>
    <br>
    <button type="submit" class="btn btn-success">Set Flight</button>
     <a href="admin.php"><button type="submit" class="btn btn-success">Back</button></a>
  </div>
 
   
  
</div>
             
  
 
    </body>
</html>